package net.qiujuer.italker.common;

/**
 * @author qiujuer
 */

public class Common {

}
