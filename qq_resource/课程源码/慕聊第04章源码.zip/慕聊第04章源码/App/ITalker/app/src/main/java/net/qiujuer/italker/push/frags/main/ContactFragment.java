package net.qiujuer.italker.push.frags.main;


import net.qiujuer.italker.common.app.Fragment;
import net.qiujuer.italker.push.R;

public class ContactFragment extends Fragment {

    public ContactFragment() {
        // Required empty public constructor
    }


    @Override
    protected int getContentLayoutId() {
        return R.layout.fragment_contact;
    }

}
