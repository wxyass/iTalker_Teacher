compile "com.android.support:design:$rootProject.ext.supportVersion"
compile "net.qiujuer.genius:ui:$rootProject.ext.geniusVersion"
compile "net.qiujuer.genius:res:$rootProject.ext.geniusVersion"
compile "de.hdodenhof:circleimageview:$rootProject.ext.circleimageviewVersion"
compile "com.github.bumptech.glide:glide:$rootProject.ext.glideVersion"

ext {
    geniusVersion = '2.0.0'
    glideVersion = '3.7.0'
    circleimageviewVersion = '2.1.0' 
}