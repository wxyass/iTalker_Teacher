package com.example.qiujuer.application.mo;

/**
 * @author qiujuer Email:qiujuer@live.cn
 * @version 1.0.0
 */
public class DeviceModel {
    private String mac;
    private int state;
    private int type;
    private String ip;
    private String deviceId;

    public DeviceModel() {
    }

    public DeviceModel(String mac, String ip) {
        this.mac = mac;
        this.ip = ip;
    }

    public String getMac() {
        return mac;
    }

    public void setMac(String mac) {
        this.mac = mac;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }
}
