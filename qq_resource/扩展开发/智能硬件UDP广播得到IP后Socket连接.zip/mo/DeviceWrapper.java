package com.example.qiujuer.application.mo;

import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.Arrays;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * @author qiujuer Email:qiujuer@live.cn
 * @version 1.0.0
 */
public class DeviceWrapper {
    private final DeviceModel model;
    private final DeviceListener listener;
    private final byte buffer[] = new byte[1024];

    private ExecutorService sender;

    private OutputStream outputStream;
    private InputStream inputStream;

    private Socket socket;

    public DeviceWrapper(DeviceModel model, DeviceListener listener) {
        this.model = model;
        this.listener = listener;

        tryLink();

        sender = Executors.newSingleThreadExecutor();
        new Thread(receiver).start();
    }

    public synchronized void tryLink() {
        close();

        try {
            socket = new Socket();
            socket.connect(new InetSocketAddress(model.getIp(), 8899), 2000);
            outputStream = socket.getOutputStream();
            inputStream = socket.getInputStream();
        } catch (IOException e) {
            e.printStackTrace();
            socket = null;
        } finally {
            notifyAll();
        }
    }

    public void send(byte[] data) {
        byte[] buf = Arrays.copyOf(data, data.length);
        SenderRunnable runnable = new SenderRunnable(buf);
        sender.execute(runnable);
    }

    public void sendHeartbeat() {
        byte[] buf = null; // 心跳数据
        SenderRunnable runnable = new SenderRunnable(buf);
        sender.execute(runnable);
    }

    public void changeAddress(String ip) {
        this.model.setIp(ip);
        tryLink();
    }

    private class SenderRunnable implements Runnable {
        final byte[] buf;

        SenderRunnable(byte[] buf) {
            this.buf = buf;
        }

        @Override
        public void run() {
            synchronized (DeviceWrapper.this) {
                if (socket == null)
                    return;

                try {
                    outputStream.write(buf);
                    outputStream.flush();
                } catch (IOException e) {
                    onLinkedBreakOff();
                }
            }
        }
    }

    private Runnable receiver = new Runnable() {
        @Override
        public void run() {
            while (true) {
                synchronized (DeviceWrapper.this) {
                    if (socket == null) {
                        try {
                            DeviceWrapper.this.wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }

                    if (socket != null) {
                        try {
                            int len = inputStream.read(buffer);
                            if (len > 0) {
                                String str = new String(buffer, 0, len);
                                if (str.contains("CONNECT OK")) {
                                    // 初次
                                    send("devicetype/2".getBytes());
                                } else {
                                    // 回送Type时
                                    if (str.startsWith("devicetype/")) {
                                        int type = Integer.valueOf(str.substring(11));
                                        model.setType(type);
                                    }
                                }
                            }
                        } catch (IOException e) {
                            onLinkedBreakOff();
                        }
                    }
                }
            }
        }
    };

    private synchronized void close() {
        closeStream(inputStream);
        closeStream(outputStream);
        if (socket != null) {
            try {
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            socket = null;
        }
    }

    private synchronized void onLinkedBreakOff() {
        close();
        listener.onLinkedBreakOff(DeviceWrapper.this);
    }

    public interface DeviceListener {
        void onLinkedBreakOff(DeviceWrapper wrapper);
    }

    private static void closeStream(Closeable closeable) {
        if (closeable == null)
            return;
        try {
            closeable.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
