package com.example.qiujuer.application.mo;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketException;

/**
 * @author qiujuer Email:qiujuer@live.cn
 * @version 1.0.0
 */
public class DataService {
    private DatagramPacket broadcastPacket, receivePacket;
    private DatagramSocket socket;

    private final Object sendLocker = new Object();
    private final Object receiveLocker = new Object();

    public DataService() throws SocketException {
        String message = "HF-A11ASSISTHREAD";
        broadcastPacket = new DatagramPacket(message.getBytes(), message.getBytes().length,
                new InetSocketAddress("255.255.255.255", '뼃'));
        receivePacket = new DatagramPacket(new byte[1024], 1024);
        socket = new DatagramSocket();
    }

    public void sendBroadcast() {
        synchronized (sendLocker) {
            try {
                socket.send(broadcastPacket);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    public String[] receive() throws IOException {
        synchronized (receiveLocker) {
            DatagramPacket packet = receivePacket;
            socket.receive(packet);
            String str = new String(packet.getData(), 0, packet.getLength());
            String args[] = str.split(",");
            if (args.length == 3) {
                return args;
            }
        }
        return null;
    }

}
