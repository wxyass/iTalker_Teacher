package com.example.qiujuer.application.mo;

import java.io.IOException;
import java.net.SocketException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author qiujuer Email:qiujuer@live.cn
 * @version 1.0.0
 */
public class Boss implements DeviceWrapper.DeviceListener {
    private boolean done = false;
    private Map<String, DeviceWrapper> devices = new ConcurrentHashMap<>();
    private DataService service;

    public void start() throws SocketException {
        service = new DataService();
        startSendBroadcastThread();
        startReceivePacketThread();
        startSendHeartThread();
    }

    private void startSendBroadcastThread() {
        new Thread() {
            @Override
            public void run() {
                while (!done) {
                    try {
                        sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                    service.sendBroadcast();
                }
            }
        }.start();
    }


    private void startReceivePacketThread() {
        new Thread() {
            @Override
            public void run() {
                String args[];
                while (!done) {
                    try {
                        args = service.receive();
                    } catch (IOException e) {
                        e.printStackTrace();
                        args = null;
                    }

                    if (args != null) {
                        String mac = args[1];
                        String ip = args[0];

                        DeviceWrapper wrapper = devices.get(mac);
                        if (wrapper == null) {
                            DeviceModel model = new DeviceModel(mac, ip);
                            wrapper = new DeviceWrapper(model, Boss.this);
                            devices.put(mac, wrapper);
                        } else {
                            wrapper.changeAddress(ip);
                        }
                    }

                }
            }
        }.start();
    }

    private void startSendHeartThread() {
        new Thread() {
            @Override
            public void run() {
                while (!done) {
                    try {
                        sleep(10000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                    for (DeviceWrapper deviceWrapper : devices.values()) {
                        deviceWrapper.sendHeartbeat();
                    }
                }
            }
        }.start();
    }

    public void exit() {
        done = true;
    }

    @Override
    public void onLinkedBreakOff(DeviceWrapper wrapper) {
        // 重连
        wrapper.tryLink();
    }
}
